package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.myapplication.Util.MyUserData;

import java.util.ArrayList;
import java.util.List;

public class UserDataHelp extends SQLiteOpenHelper {

    private static final String TAG = "UserDBHelper";
    private static final String DB_NAME = "user.db"; // 数据库的名称
    private static final int DB_VERSION = 1; // 数据库的版本号


    private static final String TABLE_NAME = "user_info";

    private static UserDataHelp mHelper = null;
    private SQLiteDatabase mRDB = null;
    private SQLiteDatabase mWDB = null;
    private UserDataHelp(Context context) {

        super(context, DB_NAME, null, DB_VERSION);
    }


    // 利用单例模式获取数据库帮助器的唯一实例
    public static UserDataHelp getInstance(Context context) {
        if (DB_VERSION > 0 && mHelper == null) {
            mHelper = new UserDataHelp(context);
        } else if (mHelper == null) {
            mHelper = new UserDataHelp(context);
        }
        return mHelper;
    }

    // 打开数据库的读连接
    public SQLiteDatabase openReadLink() {
        if (mRDB == null || !mRDB.isOpen()) {
            mRDB = mHelper.getReadableDatabase();
        }
        return mRDB;
    }
    // 打开数据库的写连接
    public SQLiteDatabase openWriteLink() {
        if (mWDB == null || !mWDB.isOpen()) {
            mWDB = mHelper.getWritableDatabase();
        }
        return mWDB;
    }
    // 关闭数据库连接
    public void closeLink() {
        if (mRDB != null && mRDB.isOpen()) {
            mRDB.close();
            mRDB = null;
        }

        if (mWDB != null && mWDB.isOpen()) {
            mWDB.close();
            mWDB = null;
        }
    }
    public void onCreate(SQLiteDatabase db) {

        //SQL语句
        String drop_sql = "DROP TABLE IF EXISTS " + TABLE_NAME + ";";

        db.execSQL(drop_sql);
        String create_sql = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + " ("
                + "_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,"
                + "name VARCHAR NOT NULL," + "Time VARCHAR NOT NULL"
                + ");";
        db.execSQL(create_sql); // 执行完整的SQL语句
    }
    // 升级数据库，执行表结构变更语句
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    // 根据指定条件删除表记录
    public int delete(String condition) {
    // 执行删除记录动作，该语句返回删除记录的数目
        return mWDB.delete(TABLE_NAME, condition, null);
    }
    // 删除该表的所有记录
    public int deleteAll() {
    // 执行删除记录动作，该语句返回删除记录的数目
        return mWDB.delete(TABLE_NAME, "1=1", null);
    }
    public int delUserById(int id){
        return mWDB.delete(TABLE_NAME,"_id=?",new String[]{String.valueOf(id)});
    }
    // 往该表添加一条记录
    public long interUser(MyUserData userData){
        ContentValues values = new ContentValues();
        values.put("name",userData.name);
        values.put("Time",userData.time);
        try {
            mWDB.beginTransaction();
            mWDB.insert(TABLE_NAME, null, values);
            mWDB.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            mWDB.endTransaction();
        }

        return 1;
    }
    public List<MyUserData> queryAllCartInfo() {
        List<MyUserData> list = new ArrayList<>();
        Cursor cursor = mRDB.query(TABLE_NAME, null, null, null, null, null, null);
        while (cursor.moveToNext()) {
            MyUserData info = new MyUserData();
            info.id = cursor.getInt(0);
            info.name = cursor.getString(1);
            info.time = cursor.getString(2);
            list.add(info);
        }
        return list;
    }
}
