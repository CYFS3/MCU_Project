package com.example.myapplication;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.Util.GetTimer;
import com.example.myapplication.Util.MyUserData;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    private  MqttClient client;

    String broker = "ssl://e6ddbc31.ala.cn-hangzhou.emqxsl.cn:8883";
    private  TextView tv_result;
    private Handler handler;
    private  TextView tv_LED;
    private  TextView tv_water;
    private final String waterId = "Sluice-001";
    private final String elecId = "Elec-001";
    private final String dormitoryId = "CYFS";
    private int temp;

    private boolean userADDFlag = false;
    private MyUserData userData=new MyUserData();

    private int hum;
    private int waterState;
    private int LEDState;
    private final String topic_sluice = "control_sluice";

    private final String topic_switch= "control_switch";
    private final String topic_monitor ="room_monitor";
    private final String topic_User = "access_control";
    private TextView tv_hum;
    private TextView tv_temp;
    private UserDataHelp userDataHelp;

    @Override
    protected void onStart() {
        super.onStart();
        // 获得数据库帮助器的实例
        userDataHelp = UserDataHelp.getInstance(this);
        // 打开数据库帮助器的读写连接
        userDataHelp.openWriteLink();
        userDataHelp.openReadLink();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        View decorView = getWindow().getDecorView();

        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        getWindow().setStatusBarColor(Color.TRANSPARENT);

        findViewById(R.id.btu_link).setOnClickListener(this);
        findViewById(R.id.btu_close_sluice).setOnClickListener(this);
        findViewById(R.id.btu_open_sluice).setOnClickListener(this);
        findViewById(R.id.btu_open_switch).setOnClickListener(this);
        findViewById(R.id.btu_close_switch).setOnClickListener(this);
        tv_LED = findViewById(R.id.tv_LED);
        tv_hum = findViewById(R.id.tv_hum);
        tv_temp = findViewById(R.id.tv_temp);
        tv_water = findViewById(R.id.tv_water);
        // 创建定时任务调度器，每隔1秒执行一次 checkConnectionStatus 方法
        handler = new Handler(Looper.getMainLooper());
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(this::checkConnectionStatus, 0, 1, TimeUnit.SECONDS);
        tv_result = findViewById(R.id.tv_result);
        findViewById(R.id.btu_dislink).setOnClickListener(this);
        findViewById(R.id.look).setOnClickListener(this);


    }

    private void checkConnectionStatus() {
        // 在非主线程中执行 UI 操作
        new Thread(() -> {
            // 进行一些耗时操作

            // 使用 Handler 切换到主线程执行 UI 操作
            new Handler(Looper.getMainLooper()).post(() -> {
                // 在这里执行 UI 操作
                handler.post(() -> {
                        if(client == null)return;
                        if (client.isConnected()) {
                            tv_result.setText("已连接");
                            tv_result.setTextColor(0xFF0000FF);
                            tv_temp.setText(String.valueOf(temp));
                            tv_temp.setTextColor(0xFF0000FF);
                            tv_hum.setText(String.valueOf(hum));
                            tv_hum.setTextColor(0xFF0000FF);
                    } else {
                        tv_result.setText("未连接");
                        tv_result.setTextColor(0xFFFF0000);
                        tv_temp.setText("NULL");
                        tv_temp.setTextColor(0xFFFF0000);
                        tv_hum.setText("NULL");
                        tv_hum.setTextColor(0xFFFF0000);
                        return;
                        // 在这里添加重新连接的逻辑
                    }
                    if(waterState == 1){
                        tv_water.setText("已开启");
                        tv_water.setTextColor(0xFF0000FF);
                    } else if (waterState == 0) {
                        tv_water.setText("未开启");
                        tv_water.setTextColor(0xFFFF0000);
                    }
                    if(LEDState == 1){
                        tv_LED.setText("已开启");
                        tv_LED.setTextColor(0xFF0000FF);
                    } else if (LEDState == 0) {
                        tv_LED.setText("未开启");
                        tv_LED.setTextColor(0xFFFF0000);
                    }
                    if(userADDFlag){
                        userADDFlag = false;
                        userData.time = GetTimer.getNowTime();
                        userDataHelp.interUser(userData);
                    }

                });
            });
        }).start();
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.look) {
            Intent intent = new Intent(this, UserData.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        }
        if(v.getId() == R.id.btu_link){
            linkMQTT();
        }
        if (client == null){
            Toast.makeText(this,"MQTT服务器没有连接",Toast.LENGTH_SHORT).show();
            return;
        }
        if(!client.isConnected()){
            Toast.makeText(this,"MQTT服务器没有连接",Toast.LENGTH_SHORT).show();
            return;
        }
        if (v.getId() == R.id.btu_close_sluice) {
            closeSluice();
        }else if (v.getId() == R.id.btu_open_sluice) {
            openSluice();
        }else if (v.getId() == R.id.btu_open_switch) {
            openSwitch();
        }else if (v.getId() == R.id.btu_close_switch) {
            closeSwitch();
        }  else if (v.getId() == R.id.btu_dislink) {
            closeLink();
        }

    }
    private void closeLink() {
        if (client != null){
            try {
                client.disconnect();
            } catch (MqttException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private void closeSwitch() {
        // 发布消息
        MqttMessage message = new MqttMessage();
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("elecId",elecId);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        try {
            jsonObject.put("state",0);

        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        message.setPayload(jsonObject.toString().getBytes());
        try {
            client.publish(topic_switch, message);
        } catch (MqttException e) {
            throw new RuntimeException(e);
        }
    }

    private void openSwitch() {
        // 发布消息
        MqttMessage message = new MqttMessage();
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("elecId",elecId);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        try {
            jsonObject.put("state",1);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        message.setPayload(jsonObject.toString().getBytes());
        try {
            client.publish(topic_switch, message);
        } catch (MqttException e) {
            throw new RuntimeException(e);
        }
    }

    private void openSluice() {
        // 发布消息
        MqttMessage message = new MqttMessage();
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("waterId",waterId);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        try {
            jsonObject.put("state",1);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        message.setPayload(jsonObject.toString().getBytes());
        try {
            client.publish(topic_sluice, message);
        } catch (MqttException e) {
            throw new RuntimeException(e);
        }
    }

    private void closeSluice() {
        MqttMessage message = new MqttMessage();
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("waterId",waterId);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        try {
            jsonObject.put("state",0);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        message.setPayload(jsonObject.toString().getBytes());
        try {
            client.publish(topic_sluice, message);
        } catch (MqttException e) {
            throw new RuntimeException(e);
        }
    }

    private void linkMQTT() {
        try {
            // 创建 Handler，并传递给回调类
            MqttSample mqttSample = new MqttSample(broker);
            client = mqttSample.getClient();
            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {

                }
                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {

                    String str = new String(message.getPayload());
                    JSONObject jsonObject = new JSONObject(str);
                        if(topic.equals(topic_sluice)){
                           if(jsonObject.get("waterId").equals(waterId)){
                               waterState = jsonObject.getInt("state");
                           }
                        } else if(topic.equals(topic_switch)){
                            if(jsonObject.get("elecId").equals(elecId)){
                                LEDState = jsonObject.getInt("state");
                            }
                        } else if(topic.equals(topic_monitor)){
                            if(jsonObject.get("dormitoryId").equals(dormitoryId)){
                               hum = jsonObject.getInt("hum");
                               temp = jsonObject.getInt("temp");
                            }
                        }else
                        if(topic.equals(topic_User)){
                            if(jsonObject.get("dormitoryId").equals(dormitoryId)){
                                userData.name = jsonObject.get("name").toString();
                                userADDFlag = true;
                            }
                        }
                }
                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {

                }
            });

        } catch (MqttException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (client != null)
        {
            try {
                client.disconnect();
            } catch (MqttException e) {
                throw new RuntimeException(e);
            }
        }

        userDataHelp.closeLink();

    }


}