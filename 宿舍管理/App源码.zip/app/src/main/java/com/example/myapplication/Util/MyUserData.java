package com.example.myapplication.Util;

public  class MyUserData {


        public int id;

        public String name;
        public String time;
    
        public MyUserData(String name, String time) {
            this.name = name;
            this.time = time;
        }
        public MyUserData(){
    
        }
    }