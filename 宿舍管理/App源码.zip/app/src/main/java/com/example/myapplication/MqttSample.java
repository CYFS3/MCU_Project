package com.example.myapplication;

import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import android.os.Handler;


public class MqttSample {



    // 主 Activity 的 Handler


    private  MqttClient client;
    int qos = 0;
    String clientId = MqttClient.generateClientId();
    // 持久化
    MemoryPersistence persistence = new MemoryPersistence();
    // MQTT 连接选项
    MqttConnectOptions connOpts = new MqttConnectOptions();
    // 设置认证信息
  public MqttSample(String broker) throws MqttException {
      connOpts.setUserName("cyfs");
      connOpts.setPassword("123456".toCharArray());
      client = new MqttClient(broker, clientId, persistence);
      client.connect(connOpts);
      client.subscribe("control_sluice", qos);
      client.subscribe("control_switch", qos);
      client.subscribe("room_monitor", qos);
      client.subscribe("access_control", qos);
  }
  public MqttClient getClient(){
      return client;
  }
}
