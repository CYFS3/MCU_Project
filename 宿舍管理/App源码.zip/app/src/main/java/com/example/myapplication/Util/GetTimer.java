package com.example.myapplication.Util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class GetTimer {
    public static String getNowTime(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(new Date());
    }
}
