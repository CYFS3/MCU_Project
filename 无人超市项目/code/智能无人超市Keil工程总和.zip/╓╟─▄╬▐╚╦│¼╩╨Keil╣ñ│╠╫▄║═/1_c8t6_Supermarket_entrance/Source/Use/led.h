#ifndef _LED_H_
#define _LED_H_
#include "config.h"

void InitLed(void);
void SetLedState(u8 LED_n,bool state);

#endif
