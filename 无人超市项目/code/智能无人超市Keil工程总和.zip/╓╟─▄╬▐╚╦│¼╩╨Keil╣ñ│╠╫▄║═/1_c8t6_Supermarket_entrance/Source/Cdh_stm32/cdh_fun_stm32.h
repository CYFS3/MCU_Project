#ifndef _CDH_FUN_STM32_
#define _CDH_FUN_STM32_
#include "stm32f10x.h"

void GPIO_Set_Bit(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin,u8 state);
#endif
