#ifndef _TIMER_H_
#define _TIMER_H_
#include "config.h"
void PWM_TIM3_Init(u16 arr,u16 psc);
void SetTIM3PWMCompare(uint16_t Compare1,uint16_t Compare2);


#endif
