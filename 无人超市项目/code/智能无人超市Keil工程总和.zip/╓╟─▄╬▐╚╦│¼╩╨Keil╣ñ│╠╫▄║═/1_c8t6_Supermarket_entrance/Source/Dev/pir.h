#ifndef _PIR_H__
#define _PIR_H__

#include "config.h"

void pir_init(void);
bool get_pir(void);

#endif
