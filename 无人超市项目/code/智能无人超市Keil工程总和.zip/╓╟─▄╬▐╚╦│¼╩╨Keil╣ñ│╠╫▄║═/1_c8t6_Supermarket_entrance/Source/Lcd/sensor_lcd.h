#ifndef _SENSOR_LCD_H_
#define _SENSOR_LCD_H_
#include "config.h"
void init_lcd_word(void);
void UpdateWord(void);
#endif
