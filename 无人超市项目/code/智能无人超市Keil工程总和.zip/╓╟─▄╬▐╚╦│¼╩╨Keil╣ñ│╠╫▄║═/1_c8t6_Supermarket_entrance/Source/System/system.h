#ifndef _SYSTEM_H_
#define _SYSTEM_H_
#include "config.h"
void SysInit(void);
#endif
