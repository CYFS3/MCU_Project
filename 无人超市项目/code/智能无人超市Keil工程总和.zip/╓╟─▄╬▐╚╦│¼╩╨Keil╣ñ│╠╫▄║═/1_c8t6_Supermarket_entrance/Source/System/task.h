#ifndef _TASK_H_
#define _TASK_H_
#include "config.h"
void Task1(void);
void Task2(void);
void Task3(void);
void Task4(void);
bool getEIC(void);
void setEIC(bool EIC_state);
void pose(u8* data);
#endif
