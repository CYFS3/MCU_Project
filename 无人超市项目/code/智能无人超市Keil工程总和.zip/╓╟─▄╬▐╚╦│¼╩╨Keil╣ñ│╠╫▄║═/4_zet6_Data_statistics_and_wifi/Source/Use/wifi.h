#ifndef _WIFI_H_
#define _WIFI_H_
#include "config.h"
void init_wifi(void);


#endif
