#ifndef _UPLOADING_H_
#define _UPLOADING_H_
#include "config.h"
void upload_indent_data(void);
void init_all_data(void);
void UploadFeedbackData(void);
#endif
