#ifndef _FIRE_H_
#define _FIRE_H_
#include "config.h"
void init_fire_sensor(void);
bool GetFireState(void);
#endif
