#ifndef _LIGHT_H_
#define _LIGHT_H_
#include "config.h"
u32 GetLightLux(void);
#endif
