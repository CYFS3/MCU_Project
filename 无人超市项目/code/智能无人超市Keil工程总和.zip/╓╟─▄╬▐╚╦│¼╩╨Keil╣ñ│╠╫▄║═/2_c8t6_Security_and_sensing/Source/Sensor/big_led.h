#ifndef _BIG_LED_H_
#define _BIG_LED_H_
#include "config.h"
void init_big_led(void);
void SetBigLedState(bool state);
bool GetBigLedState(void);
#endif
