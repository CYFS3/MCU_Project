#ifndef _BEEP_H_
#define _BEEP_H_
#include "config.h"
void init_beep(void);
void SetBeepState(bool state);
bool GetBeepState(void);
#endif
