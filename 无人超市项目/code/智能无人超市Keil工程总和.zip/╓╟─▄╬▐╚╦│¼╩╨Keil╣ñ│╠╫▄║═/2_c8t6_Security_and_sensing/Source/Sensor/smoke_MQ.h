#ifndef _SMOKE_MO_H_
#define _SMOKE_MO_H_
#include "config.h"
float GetSmokescope(void);
#endif
