#ifndef _SERVO_H__
#define _SERVO_H__

void Servo_Init(void);
void Servo_angle(float angle);
void Door_OFF(void);
void Door_ON(void);
#endif
