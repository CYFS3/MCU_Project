#ifndef _OPENMV_H__
#define _OPENMV_H__
#include "config.h"
void strart_face(void);
unsigned char Get_num(void);
void DisposeReturnData(u8 *str);
#endif
