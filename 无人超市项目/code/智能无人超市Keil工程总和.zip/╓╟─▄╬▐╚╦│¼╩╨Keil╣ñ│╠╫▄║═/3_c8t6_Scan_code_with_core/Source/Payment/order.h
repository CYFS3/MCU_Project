#ifndef _ORDER_H__
#define _ORDER_H__
#include "config.h"
extern bool is_EIC;
extern bool is_door;
void receive_order(char *data);
 void update_code(void);
 #endif
